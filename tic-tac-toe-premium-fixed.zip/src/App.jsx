import React from 'react'
import TicTacToePremium from './components/TicTacToePremium'

export default function App(){
  return <TicTacToePremium />
}
